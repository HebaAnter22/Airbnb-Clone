﻿namespace API.DTOs
{
    public class GoogleAuthDto
    {
        public string IdToken { get; set; }
    }
}
