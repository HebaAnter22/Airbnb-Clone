namespace API.DTOs
{
    public class AmenityCreateDto
    {
        public string Name { get; set; }
        public string Category { get; set; }
        public string IconUrl { get; set; }
    }
} 