﻿namespace API.DTOs.Profile
{
    public class WhishListDto
    {
        public int PropertyId { get; set; }
    }
}
